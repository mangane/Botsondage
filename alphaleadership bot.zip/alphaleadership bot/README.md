# Bot2Test (v.FR)
Le Bot Discord pour les nuls - Créer son bot Discord sans savoir coder !

Vous avez toujours rêvez d'avoir votre propre bot Discord mais vous ne savez pas comment vous y prendre ? Quel langage utilisé ?  

Ne vous inquiétez pas, Bot2Test est là pour vous aider ! Ce bot a été créé pour vous simplifier la vie au maximum !

Développé en JavaScript comme 80% des bots Discord, Bot2Test est d'une simplicité d'utilisation incontestable !

Vous n'avez pas besoin de savoir coder ! Téléchargez juste Bot2Test et suivez les instructions dans ce dernier pour l'utiliser !

Si vous rencontrez un problème vous pouvez venir vous faire aider sur notre Discord ( https://discord.me/pimpmybot ou https://discord.gg/8648RT6 ).

Des mises à jours régulières auront lieu avec de nombreuses commandes qui arriveront prochainement :P


Merci de ne pas vendre ou faire un usage commercial de ce que nous vous proposons !

Tout ce que nous mettons sur Github est sous licence et ne doit être utilisé que dans un but éducatif et de simplicité de fabrication.

Si toutefois des personnes venaient à vendre nos réalisations, merci de nous le signaler, nous ferrons tout notre possible pour les en empêcher.
