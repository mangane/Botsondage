# New Changes 
New changes to `config.json` include:
```
	"logAll": "no",
	"botSupport": "yes",
```
